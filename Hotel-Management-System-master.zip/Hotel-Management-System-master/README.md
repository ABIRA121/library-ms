# Hotel-Management-System
Management System using java/javafx
kindly have the following prerequisite :
1. IntelliJ IDEA
2. mysql-connector-java-8.0.19 library and insert it into the intellij
3. download the .sql file and run it into the mysql workbench
4. run the code
5. Note that the view size is varying from laptop to another due to the pixels of each system. 
The project in the video is being run on a laptop with screen pixels 3200x1800 
6. In the video, we will login as a manager, add/remove/update the following :
    - customer
    - employee
    - reservation
    - roomservices
    - role
    - services
7. then , we will login as a receptionist but with less privileges
8.  last, we will login as a customer to check the invoice only
thank you:)
