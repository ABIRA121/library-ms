package User;

public class serviceroom {
    int totalcost;
    String roomid;
    String customerid;

    public int getTotalcost() {
        return totalcost;
    }

    public void setTotalcost(int totalcost) {
        this.totalcost = totalcost;
    }

    public String getRoomid() {
        return roomid;
    }

    public void setRoomid(String roomid) {
        this.roomid = roomid;
    }

    public String getHotelid() {
        return customerid;
    }

    public void setHotelid(String customerid) {
        this.customerid = customerid;
    }
}
